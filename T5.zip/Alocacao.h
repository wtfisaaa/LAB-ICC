void VerifAlocacaoPDados(dados *ponteiro);
void VerifAlocacaoPPTab(peca **ponteiro);
void VerifAlocacaoPTab(peca *ponteiro);
void LiberarMemoria(dados *Jogador,int Njogadores,peca **Tabuleiro,int *tam,peca **PecasRestantes,int *qPecasRestantes,int *Ptemp);