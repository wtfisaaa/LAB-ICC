peca **AtualizarTabuleiro(peca **Tabuleiro,int *tamV,int tamN);
void PrintarTabuleiro(peca **Tabuleiro,int *tam,int Altura[2],int Largura[2]);
void DefinirCor(peca Peca);